<?PHP
//Conexão com o Banco de Dados
$connect = pg_connect(getenv("DATABASE_URL"));
?>